const
    httpCodeMap = new Map([
        [ 100, {
            title : "Continue",
            description : "Headers approved, send body"
        }],
        [ 101, {
            title       : "Switching Protocols",
            description : "Switching to protocol requested by client"
        }],
        [ 103, {
            title       : "Early Hints",
            description : "Client hints to server what resources it will likely request next"
        }],
        [ 200, { // we use this one and 204
            title       : "OK",
            description : "Processing completed successfully, and there is a payload of response data"
        }],
        [ 201, {
            title       : "Created", // use 204
            description : "Resource created, per client request"
        }],
        [ 202, {
            title       : "Accepted", // use 204, or if you have something to say, use 200
            description : "Processing will continue without further notification of progress, completion, or failure"
        }],
        [ 203, {
            title       : "Non-Authoritative Information",
            description : "A proxy has modified the original (such as to eliminate malware)"
        }],
        [ 204, { // we use this one and 200
            title       : "No Content",
            description : "Processing completed successfully, and no returned data is called for"
        }],
        [ 205, {
            title       : "Reset Content",
            description : "Processing completed -- client should re-fetch or resume an initial state"
        }],
        [ 206, {
            title       : "Partial Content",
            description : "Part of a large download provided on this call, and the client can ask for the next chunk"
        }],
        [ 207, {
            title       : "Multi-Status",
            description : "Responsive data provides individual status codes for sub-tasks of request"
        }],
        [ 208, {
            title       : "Already Reported",
            description : "See previous multi-status response, nothing has changed"
        }],
        [ 226, {
            title       : "IM Used",
            description : "im === 'instance manipulation' for providing a delta between previous and current version"
        }],
        [ 300, {
            title       : "Multiple Choices",
            description : "Client to resubmit request specifying one of the choices presented, such as a video format"
        }],
        [ 301, {
            title       : "Moved Permanently",
            description : "Repeat request to the provided URI, and update yourself to always use this other URI"
        }],
        [ 303, {
            title       : "See Other",
            description : "As a next step, navigate to the provided URI"
        }],
        [ 304, {
            title       : "Not Modified",
            description : "No change since your last identical request"
        }],
        [ 307, {
            title       : "Temporary Redirect",
            description : "Request discarded -- send identical request to this other URI, this is temporary"
        }],
        [ 308, {
            title       : "Permanent Redirect",
            description : "Request discarded -- send identical request to this other URI, this is a permanent change"
        }],
        [ 400, {
            title       : "Bad Request",
            description : "Malformed request"
        }],
        [ 401, { // we use this one
            title       : "Unauthorized",
            description : "User authenticated, but not authorized for requested service"
        }],
        [ 402, {
            title       : "Payment Required",
            description : "Payment is required before you can use this service"
        }],
        [ 403, { // we use this one
            title       : "Forbidden", // we use this primarily as an opaque rejection of a suspected attack
            description : "User cannot access this service" // theoretically because user is not authenticated
        }],
        [ 404, { // we use this one at the web server level
            title       : "Not Found",
            description : "Requested URI was not found"
        }],
        [ 405, {
            title       : "Method Not Allowed",
            description : "The HTTP method used is not supported by this service"
        }],
        [ 406, {
            title       : "Not Acceptable",
            description : "Server cannot provide a response in any of the forms listed in client's Accept headers"
        }],
        [ 407, {
            title       : "Proxy Authentication Required",
            description : "Requestor must authenticate with proxy"
        }],
        [ 408, { // we use this one
            title       : "Request Timeout",
            description : "Request came too late, for example, past session timeout"
        }],
        [ 409, { // we use this one
            title       : "Conflict",
            description : "Request rejected as it would have violated an application constraint"
        }],
        [ 410, {
            title       : "Gone",
            description : "Requested resource has been deleted (not moved), and should not be requested again"
        }],
        [ 411, {
            title       : "Length Required",
            description : "Length info is required for this request and was not given"
        }],
        [ 412, {
            title       : "Precondition Failed",
            description : "A condition the client set in the request headers cannot be met by the server"
        }],
        [ 413, { // we use this one
            title       : "Content Too Large",
            description : "Request exceeds the allowed size"
        }],
        [ 414, {
            title       : "URI Too Long",
            description : "Possibly due to the size of url parameters, the given URI is too long"
        }],
        [ 415, {
            title       : "Unsupported Media Type",
            description : "Unsupported media type, such as uploading an unsupported file type"
        }],
        [ 416, {
            title       : "Range Not Satisfiable",
            code        : 416, // for example, beyond the last row in a database table
            description : "Request asks for a range the server cannot supply"
        }],
        [ 417, {
            title       : "Expectation Failed",
            description : "Client gave an Expect header that the server cannot satisfy"
        }],
        [ 421, {
            title       : "Misdirected Request",
            description : "Server is not intended to service the given request"
        }],
        [ 422, {
            title       : "Unprocessable Entity",
            description : "Request is well-formed but processing is prevented by semantic error"
        }],
        [ 423, {
            title       : "Locked",
            description : "Account or resource locked"
        }],
        [ 424, {
            title       : "Failed Dependency",
            description : "Request depends on a failed prior request or other unavailable precondition"
        }],
        [ 426, {
            title       : "Upgrade Required",
            description : "Server requires client to make a protocol upgrade, for example, from SSL to TLS"
        }],
        [ 428, {
            title       : "Precondition Required",
            description : "Client must specify a precondition to satisfy to avoid a conflict"
        }],
        [ 429, {
            title       : "Too Many Requests",
            description : "Rate limit exceeded -- request ignored, reduce request frequency"
        }],
        [ 451, {
            title       : "Unavailable For Legal Reasons",
            description : "Requested resource is not legally available at present"
        }],
        [ 500, { // we use this one
            title       : "Server Error",
            description : "Something went wrong on the server"
        }],
        [ 501, {
            title       : "Not Implemented",
            description : "Planned but unimplemented service"
        }],
        [ 502, {
            title       : "Bad Gateway",
            description : "A server upstream from a proxy or gateway gave an error response"
        }],
        [ 503, { // we use this one
            title       : "Service Unavailable",
            description : "Server temporarily overloaded or otherwise temporarily unable to process request"
        }],
        [ 504, {
            title       : "Gateway Timeout",
            description : "A server upstream from a proxy or gateway did not respond within the timeout in use"
        }],
        [ 505, {
            title       : "HTTP Version Not Supported",
            description : "Unsupported http version"
        }],
        [ 506, {
            title       : "Variant Also Negotiates",
            description : "A circular reference was discovered during content negotiation"
        }],
        [ 507, {
            title       : "Insufficient Storage",
            description : "Sufficient storage cannot be allocated"
        }],
        [ 508, {
            title       : "Loop Detected",
            description : "Infinite loop detected"
        }],
        [ 510, {
            title       : "Not Extended",
            description : "Client requested an HTTP extension the server does not provide"
        }],
        [ 511, {
            title       : "Network Authentication Required",
            description : "For example, to get out of a \"walled garden\" at a public WiFi hot spot"
        }]
    ]);

export { httpCodeMap };
